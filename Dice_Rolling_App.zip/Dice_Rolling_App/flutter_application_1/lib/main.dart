import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(
    dice()
  );
  
}
class dice extends StatefulWidget {
  const dice({super.key});

  @override
  State<dice> createState() => _diceState();
}

class _diceState extends State<dice> {
  int dice_no = 1;
  
  String get = '';
  void update() {
    
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            children: [
              Image.asset('$get'),
              ElevatedButton(
                onPressed:()=> setState(() {
                  dice_no = Random().nextInt(6) + 1;
                  if(dice_no == 1){
                    get='assetImage/dice1.png';
                  }
                  else if(dice_no == 2){
                    get='assetImage/dice2.png';
                  }
                  else if(dice_no == 3){
                    get='assetImage/dice3.png';
                  }
                  else if(dice_no == 4){
                    get='assetImage/dice4.png';
                  }
                  else if(dice_no == 5){
                    get='assetImage/dice5.png';
                  }
                  else if(dice_no == 6){
                    get='assetImage/dice6.png';
                  }
                  
                  
                }), child: Text('Rolling'),)
            ]
          ),
        ) ,
        backgroundColor: Colors.red[900],
      ),
      debugShowCheckedModeBanner: false,
    );
    
  }
}

